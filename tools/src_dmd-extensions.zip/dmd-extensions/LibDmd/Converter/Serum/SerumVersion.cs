﻿// ReSharper disable InconsistentNaming
namespace LibDmd.Converter.Serum
{
	/// <summary>
	/// Returned by Serum_Load in *SerumVersion
	/// </summary>
	enum SerumVersion
	{
		Version1 = 1,
		Version2 = 2
	}
}
