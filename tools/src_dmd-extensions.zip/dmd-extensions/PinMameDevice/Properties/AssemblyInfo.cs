﻿using System.Reflection;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("DmdDevice.dll")]
[assembly: AssemblyProduct("Universal DmdDevice.dll for Visual PinMAME")]
[assembly: AssemblyDescription("Universal DmdDevice.dll for Visual PinMAME for all displays, inclusively frame-by-frame coloring support.")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("3e9138da-a0a5-449e-bfd2-965e38b9182e")]
