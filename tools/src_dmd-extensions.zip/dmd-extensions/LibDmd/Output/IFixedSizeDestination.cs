﻿using LibDmd.Frame;

namespace LibDmd.Output
{
	/// <summary>
	/// Indicates that an output device's pixel dimensions are constant.
	/// </summary>
	/// 
	/// <remarks>
	/// By constant we mean it doesn't change, meaning if the source happens to
	/// change dimensions, the render graph will need to resize the data.
	/// </remarks>
	public interface IFixedSizeDestination
	{
		/// <summary>
		/// Size of the output device in pixels.
		/// </summary>
		Dimensions FixedSize { get; }

		/// <summary>
		/// Allow scaling to HD for this destination.
		/// </summary>
		bool DmdAllowHdScaling { get; }
	}
}
